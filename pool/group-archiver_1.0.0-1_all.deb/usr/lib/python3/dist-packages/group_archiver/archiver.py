import os
import pwd
import grp
import shutil
import logging
from pathlib import Path
from typing import List, Set


def get_group(group_name: str) -> grp.struct_group:
    try:
        return grp.getgrnam(group_name)
    except KeyError:
        raise ValueError(f"Group '{group_name}' not found")


def get_users(group: grp.struct_group) -> List[pwd.struct_passwd]:
    users = set(group.gr_mem)

    for u in pwd.getpwall():
        if u.pw_gid == group.gr_gid:
            users.add(u.pw_name)

    result: List[pwd.struct_passwd] = []
    for name in users:
        try:
            result.append(pwd.getpwnam(name))
        except KeyError:
            continue

    return result


def archive_files(
    user: pwd.struct_passwd,
    allowed_uids: Set[int],
    archive_dir: str,
    logger: logging.Logger,
) -> None:
    """
    Archive files in a user's home directory if they are owned
    by any member of the specified group (via allowed_uids).
    """

    home = Path(user.pw_dir)

    if not home.exists():
        logger.warning(f"Skipping missing home directory: {home}")
        return

    for root, _, files in os.walk(home):
        for filename in files:
            src = Path(root) / filename

            try:
                stat = src.stat()
            except (FileNotFoundError, PermissionError):
                logger.warning(f"Cannot access: {src}")
                continue

            if stat.st_uid not in allowed_uids:
                continue

            rel_path = src.relative_to(home)
            dest = Path(archive_dir) / user.pw_name / "home" / rel_path

            dest.parent.mkdir(parents=True, exist_ok=True)

            # Optional: skip overwrite safety
            if dest.exists():
                logger.info(f"Already archived: {src}")
                continue

            try:
                shutil.move(str(src), str(dest))
                logger.info(f"Moved {src} -> {dest}")
            except Exception as e:
                logger.error(f"Failed to move {src}: {e}")