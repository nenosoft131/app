import argparse

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--group", required=True)
    parser.add_argument("--archive", required=True)
    args = parser.parse_args()

    print("Created BY Muhammad Usman")
