import argparse
import logging
import sys
import os
from pathlib import Path

from group_archiver.archiver import get_group, get_users, archive_files
from group_archiver.lock import FileLock


def setup_logger(log_file: str)-> logging.Logger:

    if not log_file:
        raise ValueError("log file path cannot be empty.")

    log_path = Path(log_file)
    log_path.parent.mkdir(parents=True, exist_ok=True)

    
    logging.basicConfig(
        filename=log_file,
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
    )
    return logging.getLogger("file_archiver")


def main():

    if os.geteuid() != 0:
        print("Re-running with sudo...")
        os.execvp("sudo", ["sudo", sys.executable] + sys.argv)
    
    parser = argparse.ArgumentParser(description="Archive group files")
    parser.add_argument("group", help="Group name")
    parser.add_argument("--archive-dir", default="/var/archive")
    parser.add_argument("--log-file", default="/var/log/file_archiver.log")

    args = parser.parse_args()

    logger = setup_logger(args.log_file)

    lock = FileLock("/tmp/file_archiver.lock")

    try:
        lock.acquire()
    except RuntimeError as e:
        print(e)
        sys.exit(1)

    try:
        group = get_group(args.group)
        users = get_users(group)
        for user in users:
            print(user)

        logger.info(f"Processing group: {args.group}")

        allowed_uids = {u.pw_uid for u in users}
        for user in users:
            archive_files(user, allowed_uids, args.archive_dir, logger)

        logger.info("Done")

    except Exception as e:
        logger.exception(f"Error: {e}")
        sys.exit(1)

    finally:
        lock.release()


if __name__ == "__main__":
    main()